import java.util.ArrayList;
/**
 * Customer order of a design
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class Orders
{
    // instance variables - replace the example below with your own
    private ArrayList<Customer> customer;
    private ArrayList<Design> design;
    private int customerNum;
    
    /**
     * Constructor for objects of class Orders
     */
    public Orders()
    {
        // initialise instance variables
        design = new ArrayList<>();
        customer = new ArrayList<>();
        customerNum = 10000;
        
        design.add(new Design("Nature", 300, 10, 15, 20, 25, 30));
        design.add(new Design("Tech", 350, 20, 30, 40, 50, 60));
        design.add(new Design("Business", 375, 30, 40, 50, 60, 70));
        design.add(new Design("Music", 400, 85, 95, 110, 130, 210));
        design.add(new Design("Naughty", 500, 100, 200, 300, 400, 500));
    
    }
    
    public void addCustomer(Customer newCustom)
    {
        customer.add(newCustom);
        customerNum++;
    }
    
    /**
     * Chooses the type and which features you want.  Use capitalization at start of word.
     * Place a 0 in for the features you don't want and a 1 for the
     * features you do want.
     */
    public void createOrder(String type, int f1, int f2, int f3, int f4, int f5)
    {
        boolean found = false;
        for(Design choice : design){
            if(choice.getType().contains(type)){
                found = true;
            }
            else{
                System.out.println("Sorry, that is not a valid option.");
            }
        }
        if(found == true){
            int basePrice;
            int f1Price = 0;
            int f2Price = 0;
            int f3Price = 0;
            int f4Price = 0;
            int f5Price = 0;
            if(type == "Nature"){
                basePrice = 300;
                if(f1 == 1){
                    f1Price = 10;
                }
                if(f2 == 1){
                    f2Price = 15;
                }
                if(f3 == 1){
                    f3Price = 20;
                }
                if(f4 == 1){
                    f4Price = 25;
                }
                if(f5 == 1){
                    f5Price = 30;
                }
            }
            else if(type == "Tech"){
                basePrice = 350;
                if(f1 == 1){
                    f1Price = 20;
                }
                if(f2 == 1){
                    f2Price = 30;
                }
                if(f3 == 1){
                    f3Price = 40;
                }
                if(f4 == 1){
                    f4Price = 50;
                }
                if(f5 == 1){
                    f5Price = 60;
                }
            }
            else if(type == "Business"){
                basePrice = 375;
                if(f1 == 1){
                    f1Price = 30;
                }
                if(f2 == 1){
                    f2Price = 40;
                }
                if(f3 == 1){
                    f3Price = 50;
                }
                if(f4 == 1){
                    f4Price = 60;
                }
                if(f5 == 1){
                    f5Price = 70;
                }
            }
            else if(type == "Music"){
                basePrice = 400;
                if(f1 == 1){
                    f1Price = 85;
                }
                if(f2 == 1){
                    f2Price = 95;
                }
                if(f3 == 1){
                    f3Price = 110;
                }
                if(f4 == 1){
                    f4Price = 130;
                }
                if(f5 == 1){
                    f5Price = 210;
                }
            }
            else{
                basePrice = 500;
                if(f1 == 1){
                    f1Price = 100;
                }
                if(f2 == 1){
                    f2Price = 200;
                }
                if(f3 == 1){
                    f3Price = 300;
                }
                if(f4 == 1){
                    f4Price = 400;
                }
                if(f5 == 1){
                    f5Price = 500;
                }
            }
             Design newDesign = new Design(type, basePrice, f1Price, f2Price, f3Price, f4Price, f5Price);
        }
    }
    
    /**
     * Display order options.
     */
    public void showOptions()
    {
        int incrementer = 1;
        
        for(Design choice : design){
            System.out.println(incrementer + ": " + choice.showDesign());
            incrementer++;
        }
    }
    
    }
