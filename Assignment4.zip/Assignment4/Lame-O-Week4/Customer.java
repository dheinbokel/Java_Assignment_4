
/**
 * Keeps information about the customer.
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class Customer
{
    // instance variables
    private String lastName;
    private String firstName;
    private String companyName;
    private String address;
    private String city;
    private String state;
    private String zip;
    private String phone;
    private Design customerDesign;

    /**
     * Constructor for objects of class Customer
     */
    public Customer(Design customerDesign, String lastName, String firstName, String companyName, String address, String city, String state, String zip, String phone)
    {
        // initialise instance variables
        this.lastName = lastName;
        this.firstName = firstName;
        this.companyName = companyName;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.phone = phone;
    }

    /**
     * Gets customer last name.
     */
    public String getLastName()
    {
        // put your code here
        return lastName;
    }
    
    /**
     * Gets customer first name.
     */
    public String getFirstName()
    {
        // put your code here
        return firstName;
    }
    
    /**
     * Gets customer company name.
     */
    public String getCompanyName()
    {
        // put your code here
        return companyName;
    }
    
    /**
     * Gets customer address.
     */
    public String getAddress()
    {
        // put your code here
        return address;
    }
    
    /**
     * Gets customer city.
     */
    public String getCity()
    {
        // put your code here
        return city;
    }
    
    /**
     * Gets customer state.
     */
    public String getState()
    {
        // put your code here
        return state;
    }
    
    /**
     * Gets customer zip code.
     */
    public String getZip()
    {
        // put your code here
        return zip;
    }
    
    /**
     * Gets customer phone number as a string.
     */
    public String getPhone()
    {
        // put your code here
        return phone;
    }
    
    /**
     * Displays customer info.
     */
    public void customerInfo()
    {
        System.out.println("Customer: " + firstName + " " + lastName + ".");
        System.out.println("Company: " + companyName + " Phone: " + phone + ".");
        System.out.println("Address: " + address + "/" + city + "/" + state + "/" + zip + ".");
    }
}
