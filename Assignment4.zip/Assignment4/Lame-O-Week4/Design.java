
/**
 * The designs of the order.
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class Design
{
    // instance variables - replace the example below with your own
    private String type;
    private int base;
    private int feature1;
    private int feature2;
    private int feature3;
    private int feature4;
    private int feature5;

    /**
     * Constructor for objects of class Design
     */
    public Design(String type, int base, int f1, int f2, int f3, int f4, int f5)
    {
        // initialise instance variables
        this.type = type;
        this.base = base;
        feature1 = f1;
        feature2 = f2;
        feature3 = f3;
        feature4 = f4;
        feature5 = f5;
    }

    /**
     * Gets the type of the design.
     */
    public String getType()
    {
        // put your code here
        return type;
    }
    
    /**
     * Gets the base price of the design.
     */
    public int getBase()
    {
        // put your code here
        return base;
    }
    
    /**
     * Gets the price of the first feature.
     */
    public int getF1()
    {
        // put your code here
        return feature1;
    }
    
    /**
     * Gets the price of the second feature.
     */
    public int getF2()
    {
        // put your code here
        return feature2;
    }
    
    /**
     * Gets the price of the third feature.
     */
    public int getF3()
    {
        // put your code here
        return feature3;
    }
    
    /**
     * Gets the price of the fourth feature.
     */
    public int getF4()
    {
        // put your code here
        return feature4;
    }
    
    /**
     * Gets the price of the fifth feature.
     */
    public int getF5()
    {
        // put your code here
        return feature5;
    }
    
    /**
     * Displays designChoice.
     */
    public String showDesign()
    {
        // put your code here
        return "Type: " + type + ", Base price: " + base + ", Features: " +
        "1: " + feature1 + ", 2: " + feature2 + ", 3: " + feature3 + ", 4: " + feature4 +
        ", 5: " + feature5;
    }
}
